data:extend(
{
  {
    type = "recipe-category",
    name = "pressure-pump"
  },
  {
    type = "recipe-category",
    name = "nuclear-fission-reactor-kit"
  },

})
