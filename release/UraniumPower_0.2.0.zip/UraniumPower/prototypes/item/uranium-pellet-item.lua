data:extend({
  {
    type = "item",
    name = "uranium-pellet-depleted",
    icon = "__UraniumPower__/graphics/icons/uranium-pellet-depleted.png",
    flags = {"goes-to-main-inventory"},
    subgroup = "intermediate-product",
    order = "d[steel-plate]",
    stack_size = 100
  },
--[[
  {
    type = "item",
    name = "uranium-pellet-i",
    icon = "__UraniumPower__/graphics/icons/uranium-pellet-i.png",
    flags = {"goes-to-main-inventory"},
    subgroup = "intermediate-product",
    order = "d[steel-plate]",
    stack_size = 100
  },
  {
    type = "item",
    name = "uranium-pellet-ii",
    icon = "__UraniumPower__/graphics/icons/uranium-pellet-ii.png",
    flags = {"goes-to-main-inventory"},
    subgroup = "intermediate-product",
    order = "d[steel-plate]",
    stack_size = 100
  },
  {
    type = "item",
    name = "uranium-pellet-iii",
    icon = "__UraniumPower__/graphics/icons/uranium-pellet-iii.png",
    flags = {"goes-to-main-inventory"},
    subgroup = "intermediate-product",
    order = "d[steel-plate]",
    stack_size = 100
  },
]]
  {
    type = "item",
    name = "uranium-pellet-iiii",
    icon = "__UraniumPower__/graphics/icons/uranium-pellet-iiii.png",
    flags = {"goes-to-main-inventory"},
    subgroup = "intermediate-product",
    order = "d[steel-plate]",
    stack_size = 100
  },
  {
    type = "item",
    name = "uranium-pellet-iiiii",
    icon = "__UraniumPower__/graphics/icons/uranium-pellet-iiiii.png",
    flags = {"goes-to-main-inventory"},
    subgroup = "intermediate-product",
    order = "d[steel-plate]",
    stack_size = 100
  },
  {
    type = "item",
    name = "uranium-pellet-iiiiii",
    icon = "__UraniumPower__/graphics/icons/uranium-pellet-iiiiii.png",
    flags = {"goes-to-main-inventory"},
    subgroup = "intermediate-product",
    order = "d[steel-plate]",
    stack_size = 100
  },
  {
    type = "item",
    name = "uranium-pellet-iiiiiii",
    icon = "__UraniumPower__/graphics/icons/uranium-pellet-iiiiiii.png",
    flags = {"goes-to-main-inventory"},
    subgroup = "intermediate-product",
    order = "d[steel-plate]",
    stack_size = 100
  },
  {
    type = "item",
    name = "uranium-pellet-iiiiiiii",
    icon = "__UraniumPower__/graphics/icons/uranium-pellet-iiiiiiii.png",
    flags = {"goes-to-main-inventory"},
    subgroup = "intermediate-product",
    order = "d[steel-plate]",
    stack_size = 100
  },
  {
    type = "item",
    name = "uranium-pellet-iiiiiiiii",
    icon = "__UraniumPower__/graphics/icons/uranium-pellet-iiiiiiiii.png",
    flags = {"goes-to-main-inventory"},
    subgroup = "intermediate-product",
    order = "d[steel-plate]",
    stack_size = 100
  },
})