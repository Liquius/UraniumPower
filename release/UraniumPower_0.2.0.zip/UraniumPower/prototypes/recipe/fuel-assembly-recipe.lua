data:extend(
{
--[[
  {
    type = "recipe",
    name = "fuel-assembly-i",
    enabled = "false",
    ingredients =
    {
      {"uranium-pellet-i", 50},
      {"steel-plate", 2}
    },
    result = "fuel-assembly-i"
  },
  {
    type = "recipe",
    name = "fuel-assembly-ii",
    enabled = "false",
    ingredients =
    {
      {"uranium-pellet-ii", 50},
      {"steel-plate", 2}
    },
    result = "fuel-assembly-ii"
  },
  {
    type = "recipe",
    name = "fuel-assembly-iii",
    enabled = "false",
    ingredients =
    {
      {"uranium-pellet-iii", 50},
      {"steel-plate", 2}
    },
    result = "fuel-assembly-iii"
  },
]]
  {
    type = "recipe",
    name = "fuel-assembly-iiii",
    enabled = "false",
    ingredients =
    {
      {"uranium-pellet-iiii", 50},
      {"steel-plate", 2}
    },
    result = "fuel-assembly-iiii"
  },
  {
    type = "recipe",
    name = "fuel-assembly-iiiii",
    enabled = "false",
    ingredients =
    {
      {"uranium-pellet-iiiii", 50},
      {"steel-plate", 2}
    },
    result = "fuel-assembly-iiiii"
  },
  {
    type = "recipe",
    name = "fuel-assembly-iiiiii",
    enabled = "false",
    ingredients =
    {
      {"uranium-pellet-iiiiii", 50},
      {"steel-plate", 2}
    },
    result = "fuel-assembly-iiiiii"
  },
  {
    type = "recipe",
    name = "fuel-assembly-iiiiiii",
    enabled = "false",
    ingredients =
    {
      {"uranium-pellet-iiiiiii", 50},
      {"steel-plate", 2}
    },
    result = "fuel-assembly-iiiiiii"
  },
  {
    type = "recipe",
    name = "fuel-assembly-iiiiiiii",
    enabled = "false",
    ingredients =
    {
      {"uranium-pellet-iiiiiiii", 50},
      {"steel-plate", 2}
    },
    result = "fuel-assembly-iiiiiiii"
  },
  {
    type = "recipe",
    name = "fuel-assembly-iiiiiiiii",
    enabled = "false",
    ingredients =
    {
      {"uranium-pellet-iiiiiiiii", 50},
      {"steel-plate", 2}
    },
    result = "fuel-assembly-iiiiiiiii"
  },
}
)
