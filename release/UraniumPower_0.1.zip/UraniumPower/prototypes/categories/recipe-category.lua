data:extend(
{
  {
    type = "recipe-category",
    name = "centrifuge"
  },

  {
    type = "recipe-category",
    name = "nuclear-fission-reactor"
  },

})
